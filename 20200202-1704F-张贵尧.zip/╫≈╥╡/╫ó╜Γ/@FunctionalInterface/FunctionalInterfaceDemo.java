package wwww.baidu.com

	@FunctionalInterface
    interface GreetingService 
    {
        void sayMessage(String message);
        static void printHello(){
            System.out.println("HelloWord");
        }
    }