﻿package www.baidu.com;
 
import java.util.ArrayList;
 
public class SafeVarargsDemoTest {
	public static void main(String[] args) {
		System.out.println(VarargsWaring.useVarargs(new ArrayList<String>()));
}