﻿package www.baidu.com;
 
import java.util.ArrayList;
 
 
//局部变量、接口类型、超类和接口实现类，甚至可以用在函数的异常定义上
public class SafeVarargsDemo {
	@SafeVarargs
	public static<T> T useVarargs(T... args){
		System.out.println(args.length);
		return args.length > 0?args[0]:null;
	}
}



 