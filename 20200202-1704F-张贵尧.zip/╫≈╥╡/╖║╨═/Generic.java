package www.zgy.demo;

public interface GenericTest {
    <E> String beautiful(E e);
}

public class Demo implements GenericTest {
    @Override
    public <E> String String(E e) {
        return "BeautifulGirl";
    }
}
