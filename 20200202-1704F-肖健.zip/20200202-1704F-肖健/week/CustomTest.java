package com.company.cloud.JDKTest;

import java.lang.reflect.InvocationTargetException;

import java.lang.reflect.Method;
public class CustomTest {

    @Custom(value = "testone" )
    public void test1(){

        System.out.println("test1()方法");
    }
    @Custom("testtwo")
    public void test2(){
        System.out.println("test2()方法");
    }

    public static void main(String[] args) throws InvocationTargetException, IllegalAccessException {
        Class clazz = Custom.class;
        Method[] methods = clazz.getMethods();
        for (Method method : methods) {
            boolean flag = method.isAnnotationPresent(Custom.class);
            if (flag){
                Custom c = method.getAnnotation(Custom.class);
                System.out.println(c.value());
            }
        }
    }
}
