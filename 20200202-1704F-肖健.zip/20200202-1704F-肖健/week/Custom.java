package com.company.cloud.JDKTest;


import org.springframework.context.annotation.Configuration;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Documented
@Configuration
@Target(ElementType.METHOD)
public @interface Custom {

    String value() default  "TEST";
}
