package com.bw.haoran.xc;

@XCTag(age=5)
@XCTag(name="注解",age=9)
public class XCTagTest {
    public static void main(String[] args) {
        Class<XCTagTest> clazz = XCTagTest.class;
        /* 使用Java 8新增的getDeclaredAnnotationsByType()
         *方法获取修饰XCTagTest类的多个@XCTag注解
         * */
        XCTag[] tags = clazz.getDeclaredAnnotationsByType(XCTag.class);
        // 遍历修饰XCTagTest类的多个@XCTag注解
        for(XCTag tag : tags) {
            System.out.println(tag.name() + "-->" + tag.age());
        }
        /* 使用传统的getDeclaredAnnotation()
         *方法获取修饰XCTagTest类的@XCTags注解
         *  */
        XCTags container = clazz.getDeclaredAnnotation(XCTags.class);
        System.out.println(container);
    }
}