package com.bw.haoran.xc;

import java.lang.annotation.*;

// 指定该注解信息会保留到运行时
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@Repeatable(XCTags.class)
public @interface XCTag {
    // 为该注解定义2个成员变量
    String name() default "疯狂软件";
    int age();
}
