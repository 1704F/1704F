package com.changtao.test;

/**
 * @ClassName Test
 * @Description TODO
 * @Author ctt
 * @Date 2020/2/2 11:17
 * @Version 1.0
 */
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;


public class MyAnnTest{

    @MyAnnotation(method_name="testAnnotation1")
    public String testAnnotation1(){
        return "Hello, World!";
    }

    @MyAnnotation(method_name="testAnnotation2")
    public String testAnnotation2(){
        return "Hello, World!";
    }

    public String testAnnotation3(){
        return "Hello, World!";
    }

    public static void main(String[] args) throws UnsupportedEncodingException {
        Method[] test_methods = Test.class.getMethods();

        for(Method m : test_methods){
            if(m.isAnnotationPresent(MyAnnotation.class)){
                MyAnnotation test_annotation = m.getAnnotation(MyAnnotation.class);
                System.out.println(test_annotation.method_name());
            }
        }

    }

}