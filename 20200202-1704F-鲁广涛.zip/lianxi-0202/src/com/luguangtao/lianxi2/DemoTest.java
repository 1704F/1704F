package com.luguangtao.lianxi2;

import java.lang.reflect.Method;

public class DemoTest {

	public static void main(String[] args) {
		Method[] methods = DemoTest.class.getMethods();
		for (Method method : methods) {
			if(method.isAnnotationPresent(Demo2.class)) {
				Demo2 annotation = method.getAnnotation(Demo2.class);
				System.out.println(annotation.name());				
			}
		}
	}
	
	@Demo2(name="demo01")
	public String test01() {
		return "hi tt";
	}
	
	@Demo2(name="demo02")
	public String test02() {
		return "hi tt";
	}
	
	
}
