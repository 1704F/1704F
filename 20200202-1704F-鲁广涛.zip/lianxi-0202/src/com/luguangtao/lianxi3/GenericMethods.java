package com.luguangtao.lianxi3;

public class GenericMethods{

	public <T> void f(T t){			
		System.out.println(t.getClass().getName());		
	}	
	
	
	public <T,U,V> void g(T t,U u,V v){			
		System.out.println("1:"+t.getClass().getName()+"\r2:"+u.getClass().getName()+"\r3:"+v.getClass().getName());			
	}	
	
	
	public <T,U> void h(T t,U u,String v){	
		System.out.println("1:"+t.getClass().getName()+"\r2:"+u.getClass().getName());			
	}	
	
	
	public static void main(String[] args){		
			GenericMethods gm=new GenericMethods();		
			gm.f("123");		
			gm.f(0.1);		
			gm.f(0.1f);		
			gm.f('a');		
			gm.f(gm);		
			gm.g("123", 'b',0.1);		
			gm.h(0.2, 0.4f, "123");	
	}
}
