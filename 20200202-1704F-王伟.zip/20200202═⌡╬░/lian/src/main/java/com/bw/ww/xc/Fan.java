package com.bw.haoran.xc;

import java.util.ArrayList;
import java.util.List;

/**
 * @类名: com.bw.haoran.xc
 * @作者: lhr
 * @创建时间: 2020-02-02 20:56
 * @描述:
 **/
public class Fan{

    public static void main(String[] args) {
        List list = new ArrayList();
        list.add("123");
        String s = (String) list.get(0);

        ArrayList<Integer> list1 = new ArrayList<>();
        list.add("123");
        list.add(new Integer(1));
    }
}
