package com.bw.haoran.xc;

import java.util.ArrayList;
import java.util.List;

/**
 * @类名: com.bw.haoran.xc
 * @作者: lhr
 * @创建时间: 2020-02-02 21:02
 * @描述:
 **/
/// 这里我们在类上定义两个泛型变量
public class Generics<K, V> {

    // 方法泛型与类泛型冲突，不加注解会有警告
    // 这边的K是以传入的list的类型，而不是类中的K类型
    @SuppressWarnings("hiding")
    public <K> K testK(List<K> list){
        return list.get(0);
    }

    // 测试上面的问题，可以得出结论方法中的泛型优先级高于类，会将其覆盖
    public static void main(String[] args) {
        Generics<Object, Object> generics = new Generics<>();
        ArrayList<Integer> list = new ArrayList<>();
        Integer integer = generics.testK(list);
    }
    // 编译不通过，方法泛型不能在其他方法上使用
    /*public void  testTT(List<T> list){

    }*/
    class Inclass{
        // 编译通过，内部类可以使用类上的泛型
        public void testK(List<K> list){

        }
    }


}
