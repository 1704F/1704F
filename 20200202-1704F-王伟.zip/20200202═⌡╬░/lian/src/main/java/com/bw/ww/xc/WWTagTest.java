package com.bwie.zjh.day2.fk;

@WWTag(age=5)
@WWTag(name="疯狂Java",age=9)
public class WWTagTest {
    public static void main(String[] args) {
        Class<WWTagTest> clazz = WWTagTest.class;
        
        WWTag[] tags = clazz.getDeclaredAnnotationsByType(WWTag.class);
        // 遍历修饰WWTagTest类的多个@XCTag注解
        for(WWTag tag : tags) {
            System.out.println(tag.name() + "-->" + tag.age());
        }
        /* 使用传统的getDeclaredAnnotation()
         *方法获取修饰WWTagTest类的@XCTags注解
         *  */
        WWTags container = clazz.getDeclaredAnnotation(WWTags.class);
        System.out.println(container);
    }
}