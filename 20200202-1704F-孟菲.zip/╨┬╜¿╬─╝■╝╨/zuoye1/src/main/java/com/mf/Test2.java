package com.mf;

import java.lang.annotation.*;

//自定义注解
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
@Target({ElementType.FIELD,ElementType.METHOD})
public @interface Test2 {
    public String name() default "mf";
}
