package com.mf;

/**
 * @ClassName Test1
 * @Description: TODO
 * @Author mf
 * @Date 2020/2/2
 * @Version V1.0
 **/
//jdk 注解 重写@Override
public class Test1 {

    //@Override是帮助开发者确认子类是否正确的覆盖了父类的方法
    public void read() {
        System.out.println("parent method");
    }

    @Override
    public String toString() {
        return "Child";
    }
}
