package com.ljy;


import java.lang.annotation.*;

/**
 * @类名: com.ljy
 * @作者:
 * @创建时间: 2020-02-02 19:18
 * @描述:
 **/
//2.2自定义
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
@Target({ElementType.FIELD, ElementType.METHOD})
public @interface t2 {
    public String name() default "lgt";
}
