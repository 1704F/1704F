package com.ljy;

/**
 * @类名: com.ljy
 * @作者:
 * @创建时间: 2020-02-02 19:18
 * @描述:
 **/
//2.2jdk  重写override
public class t1 {

    //	public static void main() {
//		Text1 text1=new Text1();
//		text1.aaa();
//	}

    public static void aaa() {
        System.out.println("父方法");
    }

    @Override
    public String toString() {
        return "111";
    }
}
