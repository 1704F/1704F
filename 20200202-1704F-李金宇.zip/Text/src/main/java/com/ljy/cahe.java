package com.ljy;

/**
 * @类名: com.ljy
 * @作者:
 * @创建时间: 2020-02-02 19:22
 * @描述:
 **/
public class cahe {

    public static <K, V> V put(K key, V value) {
        // TODO Auto-generated method stub
        return null;
    }
}
