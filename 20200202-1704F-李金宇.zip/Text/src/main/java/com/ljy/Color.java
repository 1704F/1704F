package com.ljy;

/**
 * @类名: com.ljy
 * @作者:
 * @创建时间: 2020-02-02 19:26
 * @描述:
 **/
//2.1改为枚举类型
public enum Color {

    Red("红色",1), Green("绿色",2), Yello("黄色",3);
    private String name;
    private int index;



    private Color(String name, int index) {
        this.name = name;
        this.index = index;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public static String getName(int index) {
        Color[] values = Color.values();
        for (int i = 0; i < values.length; i++) {
            if(values[i].getIndex()==index){
                return values[i].getName();
            }
        }
        return null;
    }
}
