package com.ljy;

/**
 * @类名: com.ljy
 * @作者:
 * @创建时间: 2020-02-02 19:21
 * @描述:
 **/
//2.2接受泛型参数并返回泛型类型
public class t3<K,V> {
    public V put(K key, V value) {
        return cahe.put(key,value);
    }
}
